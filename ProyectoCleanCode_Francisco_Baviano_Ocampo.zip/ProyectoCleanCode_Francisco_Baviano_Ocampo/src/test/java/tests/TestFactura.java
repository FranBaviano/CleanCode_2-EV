/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package tests;

import com.mycompany.proyectocleancode_francisco_baviano_ocampo.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.DisplayName;

/**
 *
 * @author Franb
 */
public class TestFactura {
    
    @BeforeAll
    public static void setUpClass() {
        System.out.println("Van a empezar a realizarse los tests");
    }
    
    @Test
    @DisplayName("Test para comprobar la exlusividad del id del cajero")
    public void comprobarIdCajero(){
        System.out.println("Se va a comprobar si el id del cajero es unico");
        Vendedor cajero1 = new Vendedor("Juan", 36, "23456789D", 1);
        Vendedor cajero2 = new Vendedor("Pedro", 40, "12345678I", 2);
        
        assertNotEquals(cajero1.getIdVendedor(), cajero2.getIdVendedor());
    }
    
    @Test
    @DisplayName("Test para comprobar la exlusividad del id del cliente")
    public void comprobarIdCliente(){
        System.out.println("Se va a comprobar si el id del cliente es unico");
        Cliente cliente1 = new Cliente("Fran", 20, "05936286H", 1);
        Cliente cliente2 = new Cliente("David", 35, "58397822U", 2);
        
        assertNotEquals(cliente1.getIdCliente(), cliente2.getIdCliente());
    }
    
    @Test
    @DisplayName("Test para comprobar la exlusividad del id del producto")
    public void comprobarIdProducto(){
        System.out.println("Se va a comprobar si el id de los productos es unico");
        Producto producto1 = new Producto(10000,"Patata", 0.60);
        Producto producto2 = new Producto(00006, "Zanahoria",0.30);
        
        assertNotEquals(producto1.getIdProducto(), producto2.getIdProducto());
    }

    @Test
    @DisplayName("Test para comprobar la identidad de las personas")
    public void comprobarNIF(){
        System.out.println("Se va acomprobar que los NIF simpre son diferentes");
        Persona cajero = new Persona("Juan", 20, "12345678I");
        Persona cliente = new Persona("Pepe", 40, "87654321Y");
            
        assertNotEquals(cajero.getNif(), cliente.getNif());
    }
    
    @Test
    @DisplayName("Test para comprobar que el id es siempre el mismo para clientes, cajeros y productos")
    public void comprobarIDs(){
        System.out.println("Se va a comprobar que los id de los mismos productos, vendedores y clientes son siempre iguales");
        LineaDetalle[] producto = {
            new LineaDetalle(10000, "Patata", 0.60, 2, "Kg"),
            new LineaDetalle(99, "Paletilla de Jamon Serrano", 100, 1, "ud"),
            new LineaDetalle(6, "Zanahoria", 0.30, 500, "g")
        };

        Factura compra = new Factura(21, 5, 2023, "Juan", 20, "12345678I", 1, "Pepe", 40, "87654321Y", 29, producto);
        Factura compra2 = new Factura(40, 20, -2000, "Juan", 20, "12345678I", 1, "Pepe", 40, "87654321Y", 29, producto);
        
        assertAll(
                ()->{assertEquals(compra.getCliente().getIdCliente(), compra2.getCliente().getIdCliente());},
                ()->{assertEquals(compra.getVendedor().getIdVendedor(), compra2.getVendedor().getIdVendedor());},
                ()->{assertEquals(compra.getDetalle()[0].getProducto().getIdProducto(), compra2.getDetalle()[0].getProducto().getIdProducto());},
                ()->{assertEquals(compra.getDetalle()[1].getProducto().getIdProducto(), compra2.getDetalle()[1].getProducto().getIdProducto());},
                ()->{assertEquals(compra.getDetalle()[2].getProducto().getIdProducto(), compra2.getDetalle()[2].getProducto().getIdProducto());}
        );
    }
    @AfterAll
    public static void tearDownClass() {
        System.out.println("Ya se han realizado todos los tests");
    }
}
