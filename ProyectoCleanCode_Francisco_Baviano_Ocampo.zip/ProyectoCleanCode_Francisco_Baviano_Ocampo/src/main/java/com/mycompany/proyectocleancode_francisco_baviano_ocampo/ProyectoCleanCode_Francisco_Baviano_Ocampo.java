/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.proyectocleancode_francisco_baviano_ocampo;

/**
 *
 * @author Franb
 */
public class ProyectoCleanCode_Francisco_Baviano_Ocampo {

    public static void main(String[] args) {

        LineaDetalle[] producto = {
            new LineaDetalle(10000, "Patata", 0.60, 2, "Kg"),
            new LineaDetalle(99, "Paletilla de Jamon Serrano", 100, 1, "ud"),
            new LineaDetalle(6, "Zanahoria", 0.30, 500, "g")
        };

        Factura compra = new Factura(21, 5, 2023, "Juan", 20, "12345678I", 1, "Pepe", 40, "87654321Y", 29, producto);
        Factura compra2 = new Factura(40, 20, -2000, "Juan", 20, "12345678I", 1, "Pepe", 40, "87654321Y", 29, producto);

        System.out.println(compra);

        System.out.println(compra2);

    }
}
