/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectocleancode_francisco_baviano_ocampo;

/**
 *
 * @author Franb
 */
public class Fecha {
    private int dia;
    private int mes;
    private int año;
    
    public Fecha(int dia, int mes, int año){
        this.dia = dia;
        this.mes = mes;
        this.año = año;
    }
    
    public Fecha(){
        this.dia = 0;
        this.mes = 0;
        this.año = 0;
    }

    public int getDia() {
        if(dia < 0 || dia > 31){
            this.dia = 0;
        }
        return dia;
    }

    public void setDia(int dia) {this.dia = dia;}

    public int getMes() {
        if(mes < 0 || mes > 12){
            this.mes = 0;
        }
        return mes;
    }

    public void setMes(int mes) {this.mes = mes;}

    public int getAño() {
        if(año < 0){
            this.año = 0;
        }
        return año;
    }

    public void setAño(int año) {this.año = año;}
    
    @Override
    public String toString(){
        return getDia() + "/" + getMes() + "/" + getAño();
    }
    
}
