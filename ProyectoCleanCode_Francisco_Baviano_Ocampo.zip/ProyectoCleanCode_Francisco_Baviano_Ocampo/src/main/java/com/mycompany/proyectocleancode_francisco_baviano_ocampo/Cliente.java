/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectocleancode_francisco_baviano_ocampo;

/**
 *
 * @author Franb
 */
public class Cliente extends Persona{
    
    private int idCliente;
    
    public Cliente(String nombre, int edad, String nif, int idCliente){
        super(nombre, edad, nif);
        this.idCliente = idCliente;
    }
    
    public Cliente(){
        super();
        this.idCliente = 0;
    }

    public int getIdCliente() {return idCliente;}

    public void setIdCliente(int idCliente) {this.idCliente = idCliente;}
    
    @Override
    public String toString(){
        return super.toString() + " || Id: " + getIdCliente();
    }
}
