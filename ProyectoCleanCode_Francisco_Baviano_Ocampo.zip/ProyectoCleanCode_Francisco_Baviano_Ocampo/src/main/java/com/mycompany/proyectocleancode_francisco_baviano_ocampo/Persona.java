/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectocleancode_francisco_baviano_ocampo;

/**
 *
 * @author Franb
 */
public class Persona {
    
    private int edad;
    private String nombre;
    private String nif;
    
    public Persona(String nombre, int edad, String nif){
        this.edad = edad;
        this.nif = nif;
        this.nombre = nombre;
    }
    
    public Persona(){
        this.edad = 0;
        this.nif = "";
        this.nombre = "";
    }

    public int getEdad() {
        if(edad < 0 || edad > 120){
            this.edad = 0;
        }
        return edad;
    }

    public void setEdad(int edad) {this.edad = edad;}

    public String getNombre() {return nombre;}

    public void setNombre(String nombre) {this.nombre = nombre;}

    public String getNif() {
        if(nif.length() > 9){
            this.nif = "0T";
        }
        return nif;
    }

    public void setNif(String nif) {this.nif = nif;}
    
    @Override
    public String toString(){
        return " -Nombre: " + getNombre() + " || Edad: " + getEdad() + " || NIF: " + getNif();
    }
}
