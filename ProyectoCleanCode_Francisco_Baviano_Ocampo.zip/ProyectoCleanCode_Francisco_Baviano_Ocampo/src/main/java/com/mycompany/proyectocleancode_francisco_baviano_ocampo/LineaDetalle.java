/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectocleancode_francisco_baviano_ocampo;

/**
 *
 * @author Franb
 */
public class LineaDetalle {
    
    private int cantidad;
    private String medida;
    private Producto producto;
    
    public LineaDetalle(int idProducto, String nombre, double precioUnitario, int cantidad, String medida){
        this.producto = new Producto(idProducto, nombre, precioUnitario);
        this.cantidad = cantidad;
        this.medida = medida;
    }
    public LineaDetalle(){
        this.producto = new Producto();
        this.cantidad = 0;
        this.medida = "";
    }

    public int getCantidad() {
        if(cantidad < 0 || cantidad > 10000){
            this.cantidad = 0;
        }
        return cantidad;
    }

    public void setCantidad(int cantidad) {this.cantidad = cantidad;}

    public String getMedida() {return medida;}

    public void setMedida(String medida) {this.medida = medida;}

    public Producto getProducto() {return producto;}

    public void setProducto(Producto producto) {this.producto = producto;}
    
    @Override
    public String toString(){
        return   String.format("%s | %5d %s", getProducto(), getCantidad(), getMedida());
    }
}
