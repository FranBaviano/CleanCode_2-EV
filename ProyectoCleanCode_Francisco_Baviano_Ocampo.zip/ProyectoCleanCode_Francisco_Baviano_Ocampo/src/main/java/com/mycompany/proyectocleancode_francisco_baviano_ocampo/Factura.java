/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectocleancode_francisco_baviano_ocampo;

/**
 *
 * @author Franb
 */
public class Factura {
    
    private int nroFactura;
    private static int nroFacturaSiguiente = 1;
    private Fecha fecha;
    private Cliente cliente;
    private Vendedor vendedor;
    private LineaDetalle[] detalle;
    
    public Factura(int dia, int mes, int año, String nombreVendedor, int edadVendedor, String nifVendedor, int idVendedor, String nombreCliente, int edadCliente, String nifCliente, int idCliente, LineaDetalle[] productos){
        nroFactura = nroFacturaSiguiente;
        nroFacturaSiguiente++;
        this.fecha = new Fecha(dia, mes, año);
        this.vendedor = new Vendedor(nombreVendedor, edadVendedor, nifVendedor, idVendedor);
        this.cliente = new Cliente( nombreCliente, edadCliente, nifCliente, idCliente);
        this.detalle = productos;
        
    }
    
    public Factura(LineaDetalle[] productos){
        this.fecha = new Fecha();
        this.vendedor = new Vendedor();
        this.cliente = new Cliente();
        this.detalle = productos;
        
    }
    
    public LineaDetalle[] getDetalle() {
        if(detalle.length < 100){
            return detalle;
        }
        return null;
        
    }

    public void setDetalle(LineaDetalle[] detalle) {this.detalle = detalle;}

    public int getNroFactura() {return nroFactura;}

    public Fecha getFecha() {return fecha;}

    public void setFecha(Fecha fecha) {this.fecha = fecha;}

    public Cliente getCliente() {return cliente;}

    public void setCliente(Cliente cliente) {this.cliente = cliente;}

    public Vendedor getVendedor() {return vendedor;}

    public void setVendedor(Vendedor vendedor) {this.vendedor = vendedor;}
    
    @Override
    public String toString(){
        String facturaInfo = String.format("Factura [%d]\nFecha: %s\nCajero:\n%s%nCliente:\n%s%n%nDetalle de la factura:%n",
                getNroFactura(), getFecha(),  getVendedor(), getCliente());

        String infoProductos = String.format("%-5s | %-30s | %-8s | Cantidad\n============================================================\n", "ID", "Nombre", "Precio");
        String lineasDetalleInfo = "";
        for (LineaDetalle i : getDetalle()) {
            lineasDetalleInfo += String.format("%s%n", i);
        }

        return facturaInfo + infoProductos + lineasDetalleInfo;
    }

    
}
