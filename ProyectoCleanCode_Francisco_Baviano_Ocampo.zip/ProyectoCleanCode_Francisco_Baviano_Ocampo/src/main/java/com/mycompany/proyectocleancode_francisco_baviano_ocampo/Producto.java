/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectocleancode_francisco_baviano_ocampo;

/**
 *
 * @author Franb
 */
public class Producto {
    private int idProducto;
    private String nombre;
    private double precioUnitario;
    
    public Producto(int idProducto, String nombre, double precioUnitario){
        this.idProducto = idProducto;
        this.nombre = nombre;
        this.precioUnitario = precioUnitario;
    }
    
    public Producto(){
        this.idProducto = 0;
        this.nombre = "";
        this.precioUnitario = 0.0;
    }

    public int getIdProducto() {
        if(idProducto < 0 || idProducto > 10000){
            this.idProducto = 0;
        }
        return idProducto;
    }

    public void setIdProducto(int idProducto) {this.idProducto = idProducto;}

    public String getNombre() {return nombre;}

    public void setNombre(String nombre) {this.nombre = nombre;}

    public double getPrecioUnitario() {
        if(precioUnitario < 0.0){
            this.precioUnitario = 0;
        }
        return precioUnitario;
    }

    public void setPrecioUnitario(double precioUnitario) {this.precioUnitario = precioUnitario;}
    
    @Override
    public String toString(){
        return String.format("%05d | %-30s | %-8.2f", getIdProducto(), getNombre(), getPrecioUnitario());
    }
    
}
