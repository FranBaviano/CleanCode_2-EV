/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectocleancode_francisco_baviano_ocampo;

/**
 *
 * @author Franb
 */
public class Vendedor extends Persona{
    
    private int idVendedor;
    
    public Vendedor(String nombre, int edad, String nif, int idVendedor){
        super(nombre, edad, nif);
        this.idVendedor = idVendedor;
    }
    
    public Vendedor(){
        super();
        this.idVendedor = 0;
    }

    public int getIdVendedor() {
        if(idVendedor < 0 || idVendedor > 10000){
            this.idVendedor = 0;
        }
        return idVendedor;
    }

    public void setIdVendedor(int idVendedor) {this.idVendedor = idVendedor;}
    
    @Override
    public String toString(){
        return super.toString() + " || Id: " + getIdVendedor();
    }
}
